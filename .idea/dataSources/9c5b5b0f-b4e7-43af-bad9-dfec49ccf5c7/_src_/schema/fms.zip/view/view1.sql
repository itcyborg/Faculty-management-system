CREATE VIEW fms.view1 AS
  SELECT
    `fms`.`forums`.`Forum_ID`   AS `Forum_ID`,
    `fms`.`forums`.`PostDate`   AS `PostDate`,
    `fms`.`forums`.`Topic`      AS `Topic`,
    `fms`.`forums`.`ThreadBy`   AS `ThreadBy`,
    `fms`.`posts`.`PostBy`      AS `PostBy`,
    `fms`.`posts`.`PostContent` AS `PostContent`,
    `fms`.`posts`.`TimeStamp`   AS `TimeStamp`
  FROM (`fms`.`forums`
    JOIN `fms`.`posts` ON ((`fms`.`forums`.`Forum_ID` = `fms`.`posts`.`Forum_ID`)));
