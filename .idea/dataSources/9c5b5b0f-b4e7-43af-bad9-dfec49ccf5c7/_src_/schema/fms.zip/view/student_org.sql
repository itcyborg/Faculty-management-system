CREATE VIEW fms.student_org AS
  SELECT
    `fms`.`organizations`.`description`     AS `description`,
    `fms`.`organizations`.`leader`          AS `leader`,
    `fms`.`organizations`.`name`            AS `name`,
    `fms`.`organizations`.`slogan`          AS `slogan`,
    `fms`.`organizations`.`target`          AS `target`,
    `fms`.`organizations`.`type`            AS `type`,
    `fms`.`student_leaders`.`adm_number`    AS `adm_number`,
    `fms`.`student_leaders`.`leader_name`   AS `leader_name`,
    `fms`.`student_leaders`.`year_of_study` AS `year_of_study`,
    `fms`.`student_leaders`.`leader_course` AS `leader_course`,
    `fms`.`student_leaders`.`leader_phone`  AS `leader_phone`,
    `fms`.`student_leaders`.`leader_email`  AS `leader_email`,
    `fms`.`student_leaders`.`resignation`   AS `resignation`,
    `fms`.`student_leaders`.`period`        AS `period`,
    `fms`.`student_leaders`.`Org_ID`        AS `Org_ID`
  FROM (`fms`.`organizations`
    JOIN `fms`.`student_leaders` ON ((`fms`.`student_leaders`.`Org_ID` = `fms`.`organizations`.`ID`)));
